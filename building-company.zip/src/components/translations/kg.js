// translations/kg.js
const translationsKg = {
  home: "Башкы бет",
  about: "Биз жөнүндө",
  services: "Биздин кызматтар",
  faq: "КЧВ",
  contacts: "Байланыш",
};

export default translationsKg;
