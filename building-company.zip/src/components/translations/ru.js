// translations/ru.js
const translationsRu = {
  home: "Главное",
  about: "О нас",
  services: "Наши услуги",
  faq: "Часто задаваемые вопросы",
  contacts: "Контакты",
};

export default translationsRu;
