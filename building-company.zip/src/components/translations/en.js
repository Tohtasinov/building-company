// translations/en.js
const translationsEn = {
  home: "Home",
  about: "About Us",
  services: "Our Services",
  faq: "FAQ",
  contacts: "Contacts",
};

export default translationsEn;
